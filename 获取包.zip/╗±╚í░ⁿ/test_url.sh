#!/bin/sh
count=0
cat 5.txt|while read line
do
    url=$line
    count=`expr $count + 1`
    echo $count
    urlstatus=$(curl -s -m 3 -IL $url| grep "200 OK")
    if [ "$urlstatus" != "" ];then
        echo $urlstatus
        echo $url >/tmp/find_url_5.txt
    fi
done
